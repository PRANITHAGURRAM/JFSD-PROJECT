package com.example.demo1;

import org.springframework.data.jpa.repository.JpaRepository;

public interface feedback1 extends JpaRepository<Feedback, String> {

}
